#ifndef BZ_VECBFN_H
#define BZ_VECBFN_H

#ifndef BZ_VECEXPR_H
 #error <blitz/vecbfn.h> must be included via <blitz/vecexpr.h>
#endif

BZ_NAMESPACE(blitz)

// Math functions with 2 operands have not yet been implemented.

BZ_NAMESPACE_END

#endif

