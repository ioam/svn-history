#include "PWOBase.h"
#include "PWOMapping.h"
#include "PWOSequence.h"
#include "PWOMSequence.h"
#include "PWOCallable.h"

namespace Py
{
    class String: public PWOString
    {
    };
}
