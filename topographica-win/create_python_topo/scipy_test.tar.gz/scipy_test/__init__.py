
from scipy_test_version import scipy_test_version as __version__
