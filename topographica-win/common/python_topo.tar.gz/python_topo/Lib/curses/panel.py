"""curses.panel

Module for using panels with curses.
"""

__revision__ = "$Id: panel.py,v 1.2 2004/07/18 06:14:41 tim_one Exp $"

from _curses_panel import *
